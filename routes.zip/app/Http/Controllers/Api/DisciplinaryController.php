<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Disciplinary;
use App\Model\Offence;
use App\Model\Natureofpunishment;
class DisciplinaryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data=Disciplinary::all();
        return response()->json($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $offence=offence::where('offence_name',$request->offence)->get()->first();
        if(empty($offence->offence_name)){
            $offence->offence_name=$request->offence;
            $offence->save();
        }
        $punishmenttype=Natureofpunishment::where('punishment_type',$request->natureofpunishment)->get()->first();
        if(empty($punishmenttype->punishment_type)){
            $punishmenttype->punishment_type=$request->natureofpunishment;
            $punishmenttype->save();
        }
        $disciplinary=new Disciplinary();

        $disciplinary->employee_id=$request->employee_id;
        $disciplinary->offence=$request->offence;
        $disciplinary->go_date=$request->go_date;
        $disciplinary->punishment_type=$request->punishment_type;
        $disciplinary->punishment_line_1=$request->pl1;
        $disciplinary->punishment_line_2=$request->pl2;
        $disciplinary->remarks=$request->remarks;
        $disciplinary->created_at=date('Y-m-d h:i:s');
        $disciplinary->created_by=1;
        $disciplinary->save();

        return response()->json('successfully added disciplinary');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
